import numpy as np
import matplotlib as plt
from matplotlib import pyplot
import csv 
t=[]
HUCB=[]
CON=[]
LIN=[]

with open('5_log.csv', 'r') as f:
	reader = csv.reader(f)
	for i in reader:
		if i[0]!='Time':
			t.append(i[0])
			LIN.append(i[1])
			CON.append(i[3])
			HUCB.append(i[4])
ft = 14
# Nsteps = 5000
# t = np.arange(Nsteps)
print(LIN,CON,HUCB)
# plot it!
fig, ax = pyplot.subplots(1)

ax.plot(t, HUCB, lw=3, label=r'HUCB', color='green')
ax.plot(t, LIN, lw=3, label=r'LIN', color='red')
ax.plot(t, CON, lw=3, label=r'CON', color='blue')
# ax.axis(auto=True)

ax.legend(loc='upper left',fontsize=ft)
ax.set_xlabel('Round',fontsize=ft)
ax.set_ylabel('Cumulative Regret',fontsize=ft)
fig.savefig('CUCB-CRA.png')